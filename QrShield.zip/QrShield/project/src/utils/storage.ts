import { ScanHistory } from '../types';

const HISTORY_KEY = 'qr-shield-history';

export const saveToHistory = (scan: Omit<ScanHistory, 'id'>): void => {
  const history = getHistory();
  const newScan: ScanHistory = {
    ...scan,
    id: Date.now().toString() + Math.random().toString(36).substr(2, 9)
  };
  
  history.unshift(newScan);
  
  // Keep only last 100 scans
  const limitedHistory = history.slice(0, 100);
  localStorage.setItem(HISTORY_KEY, JSON.stringify(limitedHistory));
};

export const getHistory = (userId?: string): ScanHistory[] => {
  try {
    const history = JSON.parse(localStorage.getItem(HISTORY_KEY) || '[]');
    return userId ? history.filter((scan: ScanHistory) => scan.userId === userId) : history;
  } catch {
    return [];
  }
};

export const clearHistory = (userId?: string): void => {
  if (userId) {
    const allHistory = getHistory();
    const filteredHistory = allHistory.filter(scan => scan.userId !== userId);
    localStorage.setItem(HISTORY_KEY, JSON.stringify(filteredHistory));
  } else {
    localStorage.removeItem(HISTORY_KEY);
  }
};