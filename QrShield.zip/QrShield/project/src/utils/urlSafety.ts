import { URLSafetyResult } from '../types';

// Mock URL safety checker - in production, you'd use a real service like Google Safe Browsing API
export const checkURLSafety = async (url: string): Promise<URLSafetyResult> => {
  // Simulate API call
  await new Promise(resolve => setTimeout(resolve, 1500));

  // Mock dangerous domains/patterns
  const dangerousPatterns = [
    'phishing',
    'malware',
    'virus',
    'hack',
    'scam',
    'fake-bank',
    'steal-password',
    'dangerous-site.com'
  ];

  const warningPatterns = [
    'ads',
    'popup',
    'download',
    'suspicious',
    'unknown-domain.xyz',
    'short.ly'
  ];

  const urlLower = url.toLowerCase();
  
  // Check for dangerous patterns
  const isDangerous = dangerousPatterns.some(pattern => urlLower.includes(pattern));
  if (isDangerous) {
    return {
      isSafe: false,
      riskLevel: 85 + Math.floor(Math.random() * 15),
      riskDetails: [
        'Potentially malicious content detected',
        'May attempt to steal personal information',
        'Contains suspicious keywords',
        'Not verified by security databases'
      ],
      category: 'dangerous'
    };
  }

  // Check for warning patterns
  const hasWarnings = warningPatterns.some(pattern => urlLower.includes(pattern));
  if (hasWarnings) {
    return {
      isSafe: false,
      riskLevel: 40 + Math.floor(Math.random() * 30),
      riskDetails: [
        'Contains advertising or promotional content',
        'May have pop-ups or unwanted downloads',
        'Domain reputation unclear'
      ],
      category: 'warning'
    };
  }

  // Safe URLs
  const safeUrls = [
    'google.com',
    'github.com',
    'stackoverflow.com',
    'mozilla.org',
    'wikipedia.org',
    'youtube.com',
    'twitter.com',
    'facebook.com',
    'linkedin.com',
    'apple.com',
    'microsoft.com'
  ];

  const isSafe = safeUrls.some(domain => urlLower.includes(domain));
  
  return {
    isSafe: true,
    riskLevel: isSafe ? Math.floor(Math.random() * 10) : 15 + Math.floor(Math.random() * 15),
    riskDetails: isSafe ? ['Verified safe domain', 'HTTPS encryption enabled'] : ['No known security issues'],
    category: 'safe'
  };
};

export const isValidURL = (string: string): boolean => {
  try {
    new URL(string);
    return true;
  } catch (_) {
    return false;
  }
};