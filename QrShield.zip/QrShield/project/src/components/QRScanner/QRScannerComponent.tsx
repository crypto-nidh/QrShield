import React, { useEffect, useRef, useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Html5QrcodeScanner, Html5Qrcode, Html5QrcodeScanType } from 'html5-qrcode';
import { Camera, AlertTriangle, Shield, ExternalLink, X, Loader2, Upload, Video, VideoOff } from 'lucide-react';
import { checkURLSafety, isValidURL } from '../../utils/urlSafety';
import { saveToHistory } from '../../utils/storage';
import { useAuth } from '../../contexts/AuthContext';
import { URLSafetyResult } from '../../types';

const QRScannerComponent: React.FC = () => {
  const [scanner, setScanner] = useState<Html5QrcodeScanner | null>(null);
  const [html5QrCode, setHtml5QrCode] = useState<Html5Qrcode | null>(null);
  const [scannedUrl, setScannedUrl] = useState('');
  const [safetyResult, setSafetyResult] = useState<URLSafetyResult | null>(null);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [showModal, setShowModal] = useState(false);
  const [isScanning, setIsScanning] = useState(false);
  const [cameraPermission, setCameraPermission] = useState<'granted' | 'denied' | 'prompt' | 'checking'>('prompt');
  const [showPermissionModal, setShowPermissionModal] = useState(false);
  const [scanMode, setScanMode] = useState<'camera' | 'upload'>('camera');
  const scannerRef = useRef<HTMLDivElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const { user } = useAuth();

  const checkCameraPermission = async () => {
    setCameraPermission('checking');
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ video: true });
      stream.getTracks().forEach(track => track.stop());
      setCameraPermission('granted');
      return true;
    } catch (error) {
      setCameraPermission('denied');
      return false;
    }
  };

  const requestCameraPermission = async () => {
    setShowPermissionModal(true);
  };

  const handlePermissionGranted = async () => {
    setShowPermissionModal(false);
    const hasPermission = await checkCameraPermission();
    if (hasPermission) {
      initializeScanner();
    }
  };

  const initializeScanner = async () => {
    if (scannerRef.current && !scanner && cameraPermission === 'granted') {
      try {
        const newScanner = new Html5QrcodeScanner(
          'qr-reader',
          {
            fps: 10,
            qrbox: { width: 300, height: 300 },
            supportedScanTypes: [Html5QrcodeScanType.SCAN_TYPE_CAMERA],
            rememberLastUsedCamera: true,
            showTorchButtonIfSupported: true,
            showZoomSliderIfSupported: true,
            aspectRatio: 1.0,
          },
          false
        );

        newScanner.render(
          (decodedText) => handleScanSuccess(decodedText, newScanner),
          (error) => {
            // Handle scan failure silently
            console.log('Scan error:', error);
          }
        );

        setScanner(newScanner);
        setIsScanning(true);
      } catch (error) {
        console.error('Failed to initialize scanner:', error);
        setCameraPermission('denied');
      }
    }
  };

  const handleFileUpload = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    try {
      const html5QrCodeInstance = new Html5Qrcode('qr-reader-file');
      setHtml5QrCode(html5QrCodeInstance);
      
      const result = await html5QrCodeInstance.scanFile(file, true);
      await handleScanSuccess(result, null);
      
      html5QrCodeInstance.clear();
      setHtml5QrCode(null);
    } catch (error) {
      console.error('Error scanning file:', error);
      alert('Could not scan QR code from the uploaded image. Please try a clearer image.');
    }
    
    // Reset file input
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
  };

  const handleScanSuccess = async (decodedText: string, scannerInstance: Html5QrcodeScanner | null) => {
    try {
      // Stop the scanner if it exists
      if (scannerInstance) {
        await scannerInstance.clear();
        setIsScanning(false);
        setScanner(null);
      }

      // Validate URL
      if (!isValidURL(decodedText)) {
        alert('The scanned QR code does not contain a valid URL.');
        return;
      }

      setScannedUrl(decodedText);
      setIsAnalyzing(true);
      setShowModal(true);

      // Check URL safety
      const result = await checkURLSafety(decodedText);
      setSafetyResult(result);
      setIsAnalyzing(false);

      // Save to history
      if (user) {
        saveToHistory({
          userId: user.id,
          url: decodedText,
          scannedAt: new Date(),
          safetyStatus: result.category,
          riskLevel: result.riskLevel,
          riskDetails: result.riskDetails
        });
      }
    } catch (error) {
      console.error('Error processing scan:', error);
      setIsAnalyzing(false);
      alert('An error occurred while processing the QR code.');
    }
  };

  const handleOpenUrl = () => {
    window.open(scannedUrl, '_blank', 'noopener,noreferrer');
    closeModal();
  };

  const closeModal = () => {
    setShowModal(false);
    setScannedUrl('');
    setSafetyResult(null);
    setIsAnalyzing(false);
  };

  const startNewScan = () => {
    closeModal();
    if (scanMode === 'camera') {
      setTimeout(() => {
        initializeScanner();
      }, 100);
    }
  };

  const switchScanMode = (mode: 'camera' | 'upload') => {
    setScanMode(mode);
    if (scanner) {
      scanner.clear().catch(console.error);
      setScanner(null);
      setIsScanning(false);
    }
    if (mode === 'camera' && cameraPermission === 'granted') {
      setTimeout(() => {
        initializeScanner();
      }, 100);
    }
  };

  useEffect(() => {
    checkCameraPermission();

    return () => {
      if (scanner) {
        scanner.clear().catch(console.error);
      }
      if (html5QrCode) {
        html5QrCode.clear().catch(console.error);
      }
    };
  }, []);

  const getRiskColor = (category: string) => {
    switch (category) {
      case 'safe':
        return 'text-green-500';
      case 'warning':
        return 'text-yellow-500';
      case 'dangerous':
        return 'text-red-500';
      default:
        return 'text-gray-500';
    }
  };

  const getRiskIcon = (category: string) => {
    switch (category) {
      case 'safe':
        return <Shield className="h-8 w-8 text-green-500" />;
      case 'warning':
      case 'dangerous':
        return <AlertTriangle className="h-8 w-8 text-red-500" />;
      default:
        return <Shield className="h-8 w-8 text-gray-500" />;
    }
  };

  return (
    <div className="space-y-6">
      {/* Scanner Section */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="bg-white/80 dark:bg-gray-800/80 backdrop-blur-lg rounded-2xl shadow-xl border border-gray-200/20 dark:border-gray-700/30 p-6"
      >
        <div className="text-center mb-6">
          <Camera className="h-12 w-12 text-cyan-500 mx-auto mb-4" />
          <h2 className="text-2xl font-bold text-gray-900 dark:text-white mb-2">
            QR Code Scanner
          </h2>
          <p className="text-gray-600 dark:text-gray-400">
            Scan QR codes with your camera or upload an image
          </p>
        </div>

        {/* Scan Mode Toggle */}
        <div className="flex justify-center mb-6">
          <div className="bg-gray-100 dark:bg-gray-700 rounded-lg p-1 flex">
            <button
              onClick={() => switchScanMode('camera')}
              className={`flex items-center space-x-2 px-4 py-2 rounded-md transition-all ${
                scanMode === 'camera'
                  ? 'bg-white dark:bg-gray-600 text-cyan-600 dark:text-cyan-400 shadow-sm'
                  : 'text-gray-600 dark:text-gray-400'
              }`}
            >
              <Video className="h-4 w-4" />
              <span>Camera</span>
            </button>
            <button
              onClick={() => switchScanMode('upload')}
              className={`flex items-center space-x-2 px-4 py-2 rounded-md transition-all ${
                scanMode === 'upload'
                  ? 'bg-white dark:bg-gray-600 text-cyan-600 dark:text-cyan-400 shadow-sm'
                  : 'text-gray-600 dark:text-gray-400'
              }`}
            >
              <Upload className="h-4 w-4" />
              <span>Upload</span>
            </button>
          </div>
        </div>

        <div className="relative">
          {scanMode === 'camera' ? (
            <>
              <div
                id="qr-reader"
                ref={scannerRef}
                className="w-full max-w-md mx-auto rounded-lg overflow-hidden bg-gray-100 dark:bg-gray-700 min-h-[300px] flex items-center justify-center"
              />
              
              {!isScanning && !showModal && cameraPermission === 'granted' && (
                <motion.button
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  onClick={initializeScanner}
                  className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 bg-gradient-to-r from-cyan-500 to-purple-500 text-white px-6 py-3 rounded-lg font-medium hover:shadow-lg transition-all duration-300"
                >
                  Start Camera Scanner
                </motion.button>
              )}

              {cameraPermission === 'denied' && (
                <motion.div
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 text-center"
                >
                  <VideoOff className="h-12 w-12 text-gray-400 mx-auto mb-4" />
                  <p className="text-gray-600 dark:text-gray-400 mb-4">
                    Camera access is required to scan QR codes
                  </p>
                  <button
                    onClick={requestCameraPermission}
                    className="bg-gradient-to-r from-cyan-500 to-purple-500 text-white px-6 py-3 rounded-lg font-medium hover:shadow-lg transition-all duration-300"
                  >
                    Enable Camera
                  </button>
                </motion.div>
              )}

              {cameraPermission === 'prompt' && (
                <motion.div
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 text-center"
                >
                  <Camera className="h-12 w-12 text-gray-400 mx-auto mb-4" />
                  <p className="text-gray-600 dark:text-gray-400 mb-4">
                    Click to enable camera access
                  </p>
                  <button
                    onClick={requestCameraPermission}
                    className="bg-gradient-to-r from-cyan-500 to-purple-500 text-white px-6 py-3 rounded-lg font-medium hover:shadow-lg transition-all duration-300"
                  >
                    Enable Camera
                  </button>
                </motion.div>
              )}
            </>
          ) : (
            <div className="w-full max-w-md mx-auto">
              <div
                id="qr-reader-file"
                className="hidden"
              />
              <div className="border-2 border-dashed border-gray-300 dark:border-gray-600 rounded-lg p-8 text-center">
                <Upload className="h-12 w-12 text-gray-400 mx-auto mb-4" />
                <p className="text-gray-600 dark:text-gray-400 mb-4">
                  Upload an image containing a QR code
                </p>
                <input
                  ref={fileInputRef}
                  type="file"
                  accept="image/*"
                  onChange={handleFileUpload}
                  className="hidden"
                />
                <button
                  onClick={() => fileInputRef.current?.click()}
                  className="bg-gradient-to-r from-cyan-500 to-purple-500 text-white px-6 py-3 rounded-lg font-medium hover:shadow-lg transition-all duration-300"
                >
                  Choose Image
                </button>
              </div>
            </div>
          )}
        </div>

        {isScanning && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="text-center mt-4"
          >
            <div className="inline-flex items-center space-x-2 px-4 py-2 bg-cyan-500/10 text-cyan-600 dark:text-cyan-400 rounded-lg">
              <div className="w-2 h-2 bg-cyan-500 rounded-full animate-pulse" />
              <span className="text-sm font-medium">Scanning for QR codes...</span>
            </div>
          </motion.div>
        )}
      </motion.div>

      {/* Camera Permission Modal */}
      <AnimatePresence>
        {showPermissionModal && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center p-4 z-50"
          >
            <motion.div
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.9, opacity: 0 }}
              className="bg-white dark:bg-gray-800 rounded-2xl shadow-2xl max-w-md w-full p-6"
            >
              <div className="text-center">
                <Camera className="h-16 w-16 text-cyan-500 mx-auto mb-4" />
                <h3 className="text-xl font-bold text-gray-900 dark:text-white mb-4">
                  Camera Permission Required
                </h3>
                <p className="text-gray-600 dark:text-gray-400 mb-6">
                  QR Shield needs access to your camera to scan QR codes. Your privacy is protected - we only use the camera for scanning and don't store any images.
                </p>
                <div className="flex space-x-3">
                  <button
                    onClick={handlePermissionGranted}
                    className="flex-1 bg-gradient-to-r from-cyan-500 to-purple-500 text-white py-3 rounded-lg font-medium hover:shadow-lg transition-all duration-300"
                  >
                    Allow Camera Access
                  </button>
                  <button
                    onClick={() => setShowPermissionModal(false)}
                    className="px-6 py-3 bg-gray-500 text-white rounded-lg font-medium hover:bg-gray-600 transition-colors"
                  >
                    Cancel
                  </button>
                </div>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Safety Analysis Modal */}
      <AnimatePresence>
        {showModal && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center p-4 z-50"
            onClick={(e) => {
              if (e.target === e.currentTarget) closeModal();
            }}
          >
            <motion.div
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.9, opacity: 0 }}
              className="bg-white dark:bg-gray-800 rounded-2xl shadow-2xl max-w-md w-full max-h-[90vh] overflow-y-auto"
            >
              <div className="p-6">
                <div className="flex justify-between items-center mb-6">
                  <h3 className="text-xl font-bold text-gray-900 dark:text-white">
                    Security Analysis
                  </h3>
                  <button
                    onClick={closeModal}
                    className="p-2 hover:bg-gray-100 dark:hover:bg-gray-700 rounded-lg transition-colors"
                  >
                    <X className="h-5 w-5 text-gray-500" />
                  </button>
                </div>

                {isAnalyzing ? (
                  <div className="text-center py-8">
                    <Loader2 className="h-12 w-12 text-cyan-500 animate-spin mx-auto mb-4" />
                    <p className="text-gray-600 dark:text-gray-400">
                      Analyzing URL safety...
                    </p>
                  </div>
                ) : safetyResult ? (
                  <div className="space-y-6">
                    {/* URL Display */}
                    <div className="p-4 bg-gray-50 dark:bg-gray-700 rounded-lg">
                      <p className="text-sm text-gray-600 dark:text-gray-400 mb-1">Scanned URL:</p>
                      <p className="font-mono text-sm break-all text-gray-900 dark:text-white">
                        {scannedUrl}
                      </p>
                    </div>

                    {/* Safety Status */}
                    <div className="text-center">
                      {getRiskIcon(safetyResult.category)}
                      <h4 className={`text-xl font-bold mt-2 ${getRiskColor(safetyResult.category)}`}>
                        {safetyResult.category === 'safe' ? 'Safe to Visit' :
                         safetyResult.category === 'warning' ? 'Proceed with Caution' :
                         'Potentially Dangerous'}
                      </h4>
                      <p className="text-gray-600 dark:text-gray-400 mt-1">
                        Risk Level: {safetyResult.riskLevel}/100
                      </p>
                    </div>

                    {/* Risk Level Bar */}
                    <div className="w-full bg-gray-200 dark:bg-gray-700 rounded-full h-3">
                      <div
                        className={`h-3 rounded-full transition-all duration-500 ${
                          safetyResult.riskLevel < 30 ? 'bg-green-500' :
                          safetyResult.riskLevel < 70 ? 'bg-yellow-500' :
                          'bg-red-500'
                        }`}
                        style={{ width: `${safetyResult.riskLevel}%` }}
                      />
                    </div>

                    {/* Risk Details */}
                    {safetyResult.riskDetails.length > 0 && (
                      <div>
                        <h5 className="font-semibold text-gray-900 dark:text-white mb-3">
                          Security Details:
                        </h5>
                        <ul className="space-y-2">
                          {safetyResult.riskDetails.map((detail, index) => (
                            <li key={index} className="flex items-start space-x-2">
                              <div className="w-2 h-2 bg-gray-400 rounded-full mt-2 flex-shrink-0" />
                              <span className="text-sm text-gray-600 dark:text-gray-400">
                                {detail}
                              </span>
                            </li>
                          ))}
                        </ul>
                      </div>
                    )}

                    {/* Action Buttons */}
                    <div className="flex space-x-3">
                      {safetyResult.category === 'safe' ? (
                        <>
                          <motion.button
                            whileHover={{ scale: 1.02 }}
                            whileTap={{ scale: 0.98 }}
                            onClick={handleOpenUrl}
                            className="flex-1 flex items-center justify-center space-x-2 py-3 bg-gradient-to-r from-green-500 to-emerald-500 text-white rounded-lg font-medium hover:shadow-lg transition-all duration-300"
                          >
                            <ExternalLink className="h-4 w-4" />
                            <span>Open Link</span>
                          </motion.button>
                          <motion.button
                            whileHover={{ scale: 1.02 }}
                            whileTap={{ scale: 0.98 }}
                            onClick={closeModal}
                            className="px-6 py-3 bg-gray-500 text-white rounded-lg font-medium hover:bg-gray-600 transition-colors"
                          >
                            Cancel
                          </motion.button>
                        </>
                      ) : (
                        <>
                          <motion.button
                            whileHover={{ scale: 1.02 }}
                            whileTap={{ scale: 0.98 }}
                            onClick={handleOpenUrl}
                            className="flex-1 py-3 bg-gradient-to-r from-red-500 to-orange-500 text-white rounded-lg font-medium hover:shadow-lg transition-all duration-300"
                          >
                            Proceed Anyway
                          </motion.button>
                          <motion.button
                            whileHover={{ scale: 1.02 }}
                            whileTap={{ scale: 0.98 }}
                            onClick={closeModal}
                            className="px-6 py-3 bg-gray-500 text-white rounded-lg font-medium hover:bg-gray-600 transition-colors"
                          >
                            Cancel
                          </motion.button>
                        </>
                      )}
                    </div>

                    {/* Scan Again Button */}
                    <motion.button
                      whileHover={{ scale: 1.02 }}
                      whileTap={{ scale: 0.98 }}
                      onClick={startNewScan}
                      className="w-full py-3 bg-gradient-to-r from-cyan-500 to-purple-500 text-white rounded-lg font-medium hover:shadow-lg transition-all duration-300"
                    >
                      Scan Another QR Code
                    </motion.button>
                  </div>
                ) : null}
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
};

export default QRScannerComponent;