import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { useAuth } from '../contexts/AuthContext';
import { getHistory, clearHistory } from '../utils/storage';
import { History as HistoryIcon, ExternalLink, Trash2, Shield, AlertTriangle, Search, Filter } from 'lucide-react';
import { ScanHistory } from '../types';

const History: React.FC = () => {
  const { user } = useAuth();
  const [searchTerm, setSearchTerm] = useState('');
  const [filterStatus, setFilterStatus] = useState<'all' | 'safe' | 'warning' | 'dangerous'>('all');
  const [sortBy, setSortBy] = useState<'date' | 'risk'>('date');

  const userHistory = getHistory(user?.id);

  const filteredHistory = userHistory
    .filter(scan => {
      const matchesSearch = scan.url.toLowerCase().includes(searchTerm.toLowerCase());
      const matchesFilter = filterStatus === 'all' || scan.safetyStatus === filterStatus;
      return matchesSearch && matchesFilter;
    })
    .sort((a, b) => {
      if (sortBy === 'date') {
        return new Date(b.scannedAt).getTime() - new Date(a.scannedAt).getTime();
      } else {
        return (b.riskLevel || 0) - (a.riskLevel || 0);
      }
    });

  const handleClearHistory = () => {
    if (confirm('Are you sure you want to clear all scan history? This action cannot be undone.')) {
      clearHistory(user?.id);
      window.location.reload();
    }
  };

  const handleOpenUrl = (url: string) => {
    window.open(url, '_blank', 'noopener,noreferrer');
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'safe':
        return 'text-green-500 bg-green-500/10 border-green-500/20';
      case 'warning':
        return 'text-yellow-500 bg-yellow-500/10 border-yellow-500/20';
      case 'dangerous':
        return 'text-red-500 bg-red-500/10 border-red-500/20';
      default:
        return 'text-gray-500 bg-gray-500/10 border-gray-500/20';
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'safe':
        return <Shield className="h-4 w-4" />;
      case 'warning':
      case 'dangerous':
        return <AlertTriangle className="h-4 w-4" />;
      default:
        return <Shield className="h-4 w-4" />;
    }
  };

  return (
    <div className="min-h-screen py-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="mb-8"
        >
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-3xl sm:text-4xl font-bold text-gray-900 dark:text-white mb-4">
                Scan History
              </h1>
              <p className="text-lg text-gray-600 dark:text-gray-400">
                Review all your previously scanned QR codes and their security analysis.
              </p>
            </div>
            {userHistory.length > 0 && (
              <motion.button
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                onClick={handleClearHistory}
                className="flex items-center space-x-2 px-4 py-2 bg-red-500/10 hover:bg-red-500/20 text-red-600 dark:text-red-400 rounded-lg border border-red-500/20 transition-colors"
              >
                <Trash2 className="h-4 w-4" />
                <span>Clear History</span>
              </motion.button>
            )}
          </div>
        </motion.div>

        {userHistory.length > 0 ? (
          <>
            {/* Controls */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.1 }}
              className="bg-white/80 dark:bg-gray-800/80 backdrop-blur-lg rounded-2xl shadow-xl border border-gray-200/20 dark:border-gray-700/30 p-6 mb-8"
            >
              <div className="flex flex-col sm:flex-row gap-4">
                {/* Search */}
                <div className="flex-1">
                  <div className="relative">
                    <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-5 w-5 text-gray-400" />
                    <input
                      type="text"
                      placeholder="Search URLs..."
                      value={searchTerm}
                      onChange={(e) => setSearchTerm(e.target.value)}
                      className="w-full pl-10 pr-4 py-3 bg-white/50 dark:bg-gray-700/50 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-cyan-500 focus:border-transparent transition-all duration-300"
                    />
                  </div>
                </div>

                {/* Filter */}
                <div className="flex items-center space-x-2">
                  <Filter className="h-5 w-5 text-gray-400" />
                  <select
                    value={filterStatus}
                    onChange={(e) => setFilterStatus(e.target.value as any)}
                    className="px-4 py-3 bg-white/50 dark:bg-gray-700/50 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-cyan-500 focus:border-transparent transition-all duration-300"
                  >
                    <option value="all">All Status</option>
                    <option value="safe">Safe</option>
                    <option value="warning">Warning</option>
                    <option value="dangerous">Dangerous</option>
                  </select>
                </div>

                {/* Sort */}
                <select
                  value={sortBy}
                  onChange={(e) => setSortBy(e.target.value as any)}
                  className="px-4 py-3 bg-white/50 dark:bg-gray-700/50 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-cyan-500 focus:border-transparent transition-all duration-300"
                >
                  <option value="date">Sort by Date</option>
                  <option value="risk">Sort by Risk</option>
                </select>
              </div>
            </motion.div>

            {/* History List */}
            <div className="space-y-4">
              <AnimatePresence mode="popLayout">
                {filteredHistory.map((scan, index) => (
                  <motion.div
                    key={scan.id}
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, y: -20 }}
                    transition={{ delay: index * 0.05 }}
                    whileHover={{ scale: 1.01 }}
                    className="bg-white/80 dark:bg-gray-800/80 backdrop-blur-lg rounded-2xl shadow-xl border border-gray-200/20 dark:border-gray-700/30 p-6"
                  >
                    <div className="flex items-start justify-between mb-4">
                      <div className="flex items-center space-x-3">
                        <div className={`flex items-center space-x-2 px-3 py-1 rounded-full border ${getStatusColor(scan.safetyStatus)}`}>
                          {getStatusIcon(scan.safetyStatus)}
                          <span className="text-sm font-medium capitalize">
                            {scan.safetyStatus}
                          </span>
                        </div>
                        <span className="text-sm text-gray-500 dark:text-gray-400">
                          Risk: {scan.riskLevel}/100
                        </span>
                      </div>
                      <div className="flex items-center space-x-2">
                        <span className="text-sm text-gray-500 dark:text-gray-400">
                          {new Date(scan.scannedAt).toLocaleString()}
                        </span>
                        <motion.button
                          whileHover={{ scale: 1.1 }}
                          whileTap={{ scale: 0.9 }}
                          onClick={() => handleOpenUrl(scan.url)}
                          className="p-2 hover:bg-gray-100 dark:hover:bg-gray-700 rounded-lg transition-colors"
                        >
                          <ExternalLink className="h-4 w-4 text-gray-500" />
                        </motion.button>
                      </div>
                    </div>

                    <div className="mb-4">
                      <p className="font-mono text-sm text-gray-700 dark:text-gray-300 break-all bg-gray-50 dark:bg-gray-700/50 p-3 rounded-lg">
                        {scan.url}
                      </p>
                    </div>

                    {/* Risk Level Bar */}
                    <div className="mb-4">
                      <div className="flex justify-between items-center mb-2">
                        <span className="text-sm font-medium text-gray-700 dark:text-gray-300">
                          Risk Level
                        </span>
                        <span className="text-sm text-gray-500 dark:text-gray-400">
                          {scan.riskLevel}/100
                        </span>
                      </div>
                      <div className="w-full bg-gray-200 dark:bg-gray-700 rounded-full h-2">
                        <div
                          className={`h-2 rounded-full transition-all duration-500 ${
                            (scan.riskLevel || 0) < 30 ? 'bg-green-500' :
                            (scan.riskLevel || 0) < 70 ? 'bg-yellow-500' :
                            'bg-red-500'
                          }`}
                          style={{ width: `${scan.riskLevel || 0}%` }}
                        />
                      </div>
                    </div>

                    {/* Risk Details */}
                    {scan.riskDetails && scan.riskDetails.length > 0 && (
                      <div>
                        <h4 className="text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                          Security Details:
                        </h4>
                        <ul className="space-y-1">
                          {scan.riskDetails.map((detail, detailIndex) => (
                            <li key={detailIndex} className="flex items-start space-x-2">
                              <div className="w-2 h-2 bg-gray-400 rounded-full mt-1.5 flex-shrink-0" />
                              <span className="text-sm text-gray-600 dark:text-gray-400">
                                {detail}
                              </span>
                            </li>
                          ))}
                        </ul>
                      </div>
                    )}
                  </motion.div>
                ))}
              </AnimatePresence>

              {filteredHistory.length === 0 && (
                <motion.div
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  className="text-center py-12"
                >
                  <Search className="h-12 w-12 text-gray-400 mx-auto mb-4" />
                  <h3 className="text-lg font-medium text-gray-900 dark:text-white mb-2">
                    No scans found
                  </h3>
                  <p className="text-gray-500 dark:text-gray-400">
                    Try adjusting your search terms or filters.
                  </p>
                </motion.div>
              )}
            </div>
          </>
        ) : (
          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            className="text-center py-20"
          >
            <div className="bg-white/80 dark:bg-gray-800/80 backdrop-blur-lg rounded-2xl shadow-xl border border-gray-200/20 dark:border-gray-700/30 p-12 max-w-md mx-auto">
              <HistoryIcon className="h-16 w-16 text-gray-400 mx-auto mb-6" />
              <h3 className="text-2xl font-bold text-gray-900 dark:text-white mb-4">
                No Scan History
              </h3>
              <p className="text-gray-600 dark:text-gray-400 mb-8">
                You haven't scanned any QR codes yet. Start scanning to see your history here.
              </p>
              <motion.button
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                onClick={() => window.location.href = '/dashboard'}
                className="px-6 py-3 bg-gradient-to-r from-cyan-500 to-purple-500 text-white rounded-lg font-medium hover:shadow-lg hover:shadow-cyan-500/25 transition-all duration-300"
              >
                Start Scanning
              </motion.button>
            </div>
          </motion.div>
        )}
      </div>
    </div>
  );
};

export default History;