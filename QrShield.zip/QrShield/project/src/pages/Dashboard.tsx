import React from 'react';
import { motion } from 'framer-motion';
import { useAuth } from '../contexts/AuthContext';
import QRScannerComponent from '../components/QRScanner/QRScannerComponent';
import { getHistory } from '../utils/storage';
import { Shield, Scan, History, TrendingUp } from 'lucide-react';

const Dashboard: React.FC = () => {
  const { user } = useAuth();
  const userHistory = getHistory(user?.id);
  const recentScans = userHistory.slice(0, 5);
  
  const safeScans = userHistory.filter(scan => scan.safetyStatus === 'safe').length;
  const warningScans = userHistory.filter(scan => scan.safetyStatus === 'warning').length;
  const dangerousScans = userHistory.filter(scan => scan.safetyStatus === 'dangerous').length;

  const stats = [
    {
      icon: <Scan className="h-6 w-6" />,
      label: 'Total Scans',
      value: userHistory.length,
      color: 'text-cyan-500'
    },
    {
      icon: <Shield className="h-6 w-6" />,
      label: 'Safe URLs',
      value: safeScans,
      color: 'text-green-500'
    },
    {
      icon: <TrendingUp className="h-6 w-6" />,
      label: 'Warnings',
      value: warningScans,
      color: 'text-yellow-500'
    },
    {
      icon: <History className="h-6 w-6" />,
      label: 'Blocked Threats',
      value: dangerousScans,
      color: 'text-red-500'
    }
  ];

  return (
    <div className="min-h-screen py-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Welcome Section */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="mb-12"
        >
          <h1 className="text-3xl sm:text-4xl font-bold text-gray-900 dark:text-white mb-4">
            Welcome back, {user?.name}!
          </h1>
          <p className="text-lg text-gray-600 dark:text-gray-400">
            Scan QR codes safely with real-time security analysis.
          </p>
        </motion.div>

        {/* Stats Grid */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
          className="grid grid-cols-2 lg:grid-cols-4 gap-6 mb-12"
        >
          {stats.map((stat, index) => (
            <motion.div
              key={index}
              whileHover={{ scale: 1.02 }}
              className="bg-white/80 dark:bg-gray-800/80 backdrop-blur-lg rounded-2xl p-6 border border-gray-200/20 dark:border-gray-700/30"
            >
              <div className={`${stat.color} mb-3`}>
                {stat.icon}
              </div>
              <div className="text-2xl font-bold text-gray-900 dark:text-white mb-1">
                {stat.value}
              </div>
              <div className="text-sm text-gray-600 dark:text-gray-400">
                {stat.label}
              </div>
            </motion.div>
          ))}
        </motion.div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* QR Scanner */}
          <div className="lg:col-span-2">
            <QRScannerComponent />
          </div>

          {/* Recent Scans */}
          <motion.div
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 0.2 }}
            className="bg-white/80 dark:bg-gray-800/80 backdrop-blur-lg rounded-2xl shadow-xl border border-gray-200/20 dark:border-gray-700/30 p-6"
          >
            <h3 className="text-xl font-bold text-gray-900 dark:text-white mb-6">
              Recent Scans
            </h3>
            
            {recentScans.length > 0 ? (
              <div className="space-y-4">
                {recentScans.map((scan) => (
                  <div
                    key={scan.id}
                    className="p-4 bg-gray-50 dark:bg-gray-700/50 rounded-lg border border-gray-200/50 dark:border-gray-600/50"
                  >
                    <div className="flex items-start justify-between mb-2">
                      <div className={`w-3 h-3 rounded-full mt-1.5 ${
                        scan.safetyStatus === 'safe' ? 'bg-green-500' :
                        scan.safetyStatus === 'warning' ? 'bg-yellow-500' :
                        'bg-red-500'
                      }`} />
                      <span className="text-xs text-gray-500 dark:text-gray-400">
                        {new Date(scan.scannedAt).toLocaleDateString()}
                      </span>
                    </div>
                    <p className="text-sm font-mono text-gray-700 dark:text-gray-300 truncate">
                      {scan.url}
                    </p>
                    <p className={`text-xs mt-1 ${
                      scan.safetyStatus === 'safe' ? 'text-green-600 dark:text-green-400' :
                      scan.safetyStatus === 'warning' ? 'text-yellow-600 dark:text-yellow-400' :
                      'text-red-600 dark:text-red-400'
                    }`}>
                      {scan.safetyStatus === 'safe' ? 'Safe' :
                       scan.safetyStatus === 'warning' ? 'Warning' :
                       'Dangerous'} • Risk: {scan.riskLevel}/100
                    </p>
                  </div>
                ))}
              </div>
            ) : (
              <div className="text-center py-8">
                <History className="h-12 w-12 text-gray-400 mx-auto mb-4" />
                <p className="text-gray-500 dark:text-gray-400">
                  No scans yet. Start by scanning your first QR code!
                </p>
              </div>
            )}
          </motion.div>
        </div>
      </div>
    </div>
  );
};

export default Dashboard;