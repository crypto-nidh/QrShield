import React from 'react';
import { motion } from 'framer-motion';
import SignupForm from '../components/Auth/SignupForm';

const Signup: React.FC = () => {
  return (
    <div className="min-h-screen flex items-center justify-center py-12 px-4 sm:px-6 lg:px-8">
      <div className="w-full max-w-md">
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-center mb-8"
        >
          <p className="text-lg text-cyan-600 dark:text-cyan-400 font-medium">
            Scan QR without any worries.
          </p>
        </motion.div>
        <SignupForm />
      </div>
    </div>
  );
};

export default Signup;