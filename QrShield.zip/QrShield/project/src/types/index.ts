export interface User {
  id: string;
  email: string;
  name: string;
  createdAt: Date;
}

export interface ScanHistory {
  id: string;
  userId: string;
  url: string;
  scannedAt: Date;
  safetyStatus: 'safe' | 'warning' | 'dangerous';
  riskLevel?: number;
  riskDetails?: string[];
}

export interface URLSafetyResult {
  isSafe: boolean;
  riskLevel: number; // 0-100
  riskDetails: string[];
  category: 'safe' | 'warning' | 'dangerous';
}

export interface AuthContextType {
  user: User | null;
  login: (email: string, password: string) => Promise<boolean>;
  signup: (email: string, password: string, name: string) => Promise<boolean>;
  logout: () => void;
  isLoading: boolean;
}

export interface ThemeContextType {
  isDark: boolean;
  toggleTheme: () => void;
}